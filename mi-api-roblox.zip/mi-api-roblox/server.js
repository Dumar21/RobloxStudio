// server.js
import express from "express";
import cors from "cors";
import fs from "fs";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

// ===============================
// 🔒 Configuración general
// ===============================
const PORT = process.env.PORT || 3000;
const API_KEY = process.env.API_KEY || "clave_insegura";
let API_ENABLED = process.env.API_ENABLED === "true";

// ===============================
// 💾 Base de datos local (JSON)
// ===============================
const DB_PATH = "./database.json";

function loadDB() {
  if (!fs.existsSync(DB_PATH)) fs.writeFileSync(DB_PATH, JSON.stringify({ transactions: [], counter: 0 }));
  const data = fs.readFileSync(DB_PATH);
  return JSON.parse(data);
}

function saveDB(db) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
}

// ===============================
// 🧱 Middleware de seguridad
// ===============================
app.use((req, res, next) => {
  const key = req.headers.authorization?.replace("Bearer ", "");
  if (key !== API_KEY) return res.status(403).json({ error: "Acceso denegado." });
  if (!API_ENABLED) return res.status(503).json({ error: "API desactivada temporalmente." });
  next();
});

// ===============================
// 🎮 Endpoints Roblox
// ===============================

// Obtener gamepasses simulados
app.get("/gamepasses/:userId", (req, res) => {
  const userId = req.params.userId;
  res.json([
    { id: 12345, name: "VIP Pass", price: 100 },
    { id: 67890, name: "Fly Pass", price: 50 },
    { id: 24680, name: "Ultra Boost", price: 200 }
  ]);
});

// Crear transacción
app.post("/transacciones/crear", (req, res) => {
  const db = loadDB();
  const { playerId, gamepassId, price } = req.body;
  db.counter++;
  const transaction = {
    id: db.counter,
    playerId,
    gamepassId,
    price,
    time: Date.now()
  };
  db.transactions.push(transaction);
  saveDB(db);
  res.json(transaction);
});

// Confirmar compra (eliminar transacción)
app.post("/transacciones/confirmar", (req, res) => {
  const db = loadDB();
  const { transactionId } = req.body;
  db.transactions = db.transactions.filter(t => t.id !== transactionId);
  saveDB(db);
  res.json({ ok: true });
});

// Listar transacciones pendientes
app.get("/transacciones/listar", (req, res) => {
  const db = loadDB();
  res.json(db.transactions);
});

// ===============================
// 🧨 Endpoint para “matar” el sistema
// ===============================
app.post("/admin/toggle", (req, res) => {
  API_ENABLED = !API_ENABLED;
  res.json({ enabled: API_ENABLED });
});

// ===============================
// 🚀 Servidor encendido
// ===============================
app.listen(PORT, () => console.log(`✅ API de Roblox activa en puerto ${PORT}`));
